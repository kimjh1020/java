package day10;

public class Star {

	public static void main(String[] args) {
		// 별찍기 프로그램 2차원
		int i, j;//행과열
		
		for(i=0; i<5; i++) {
			for(j=0; j<=i; j++) {
				System.out.print("*"+"");
			}
			System.out.println(" ");
		}

	}

}

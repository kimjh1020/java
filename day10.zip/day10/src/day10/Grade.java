package day10;

public class Grade {

	public static void main(String[] args) {
		String[] name = {"tom","ann","jhon"};
		int[] kor= {50,30,90};
		int[] math= {33,44,55};
		int i =0;
		System.out.print("name : ");
		for(i=0; i<name.length; i++) {
		System.out.print(name[i]+" ");
		}
		System.out.println("");
		for(i=0; i<name.length; i++) {
			System.out.printf("%2d  ",kor[i]);
			}
		System.out.println("");
		for(i=0; i<name.length; i++) {
			System.out.printf("%2d  ",math[i]);
			}
		// 사람별 총합을 구하여 출력하시오.
	    System.out.println("");
	    System.out.print("total:");
	    for (i=0; i<3; i++) {
	    	//계산식
	    	int sum = kor[i] + math[i];

	    	System.out.printf(sum+" " );
	    }
	    
	}

}

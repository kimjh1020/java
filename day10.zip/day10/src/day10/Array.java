package day10;

public class Array {

	public static void main(String[] args) {
		double[] arrd=new double[5];
		arrd[0] =3.12;
		arrd[1] =1.23;
		String[] grade= {"kor","math","d"};
		char c[] = {'n','h'};
		
		//정수 배열을 선언하시오.
		int array[] ={1,2,3};
		int i;
		//배열의 세번째요소의 값을 5로 변경하시오.
		array[2] =5;
		System.out.println(" ");
		for(i=0; i<array.length; i++) {
		System.out.print(array[i]+" ");
		}
		//역순으로 출력하시오
		System.out.println(" ");

		for(i=array.length-1; i>=0; i--) {
			System.out.print(array[i]+" ");
			}
		
      

	
		}

	}


